
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pa_gf_form_view`
--

DROP TABLE IF EXISTS `pa_gf_form_view`;
CREATE TABLE `pa_gf_form_view` (
  `id` bigint(10) UNSIGNED NOT NULL,
  `form_id` mediumint(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(10) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pa_gf_form_view`
--

INSERT INTO `pa_gf_form_view` (`id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2022-10-13 11:41:23', '', 20),
(2, 1, '2022-10-17 11:26:50', '', 6),
(3, 1, '2022-10-19 11:41:13', '', 1),
(4, 1, '2022-10-24 12:07:42', '', 2),
(5, 1, '2022-10-26 18:24:19', '', 6),
(6, 1, '2022-10-29 14:37:31', '', 2),
(7, 1, '2022-11-01 18:49:38', '', 4),
(8, 1, '2022-11-04 01:32:20', '', 2),
(9, 1, '2022-11-04 01:32:20', '', 1),
(10, 1, '2022-11-05 16:02:22', '', 5),
(11, 1, '2022-11-06 16:14:00', '', 30),
(12, 1, '2022-11-10 12:05:32', '', 51);
