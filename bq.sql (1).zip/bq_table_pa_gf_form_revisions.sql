
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pa_gf_form_revisions`
--

DROP TABLE IF EXISTS `pa_gf_form_revisions`;
CREATE TABLE `pa_gf_form_revisions` (
  `id` bigint(10) UNSIGNED NOT NULL,
  `form_id` mediumint(10) UNSIGNED NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
