
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pa_gf_form`
--

DROP TABLE IF EXISTS `pa_gf_form`;
CREATE TABLE `pa_gf_form` (
  `id` mediumint(10) UNSIGNED NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_active` tinyint(10) NOT NULL DEFAULT 1,
  `is_trash` tinyint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pa_gf_form`
--

INSERT INTO `pa_gf_form` (`id`, `title`, `date_created`, `date_updated`, `is_active`, `is_trash`) VALUES
(1, 'Presupuesto', '2022-10-11 20:15:21', NULL, 1, 0);
