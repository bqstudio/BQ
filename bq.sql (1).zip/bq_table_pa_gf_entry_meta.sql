
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pa_gf_entry_meta`
--

DROP TABLE IF EXISTS `pa_gf_entry_meta`;
CREATE TABLE `pa_gf_entry_meta` (
  `id` bigint(10) UNSIGNED NOT NULL,
  `form_id` mediumint(10) UNSIGNED NOT NULL DEFAULT 0,
  `entry_id` bigint(10) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `item_index` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
