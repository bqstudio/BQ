
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pa_usermeta`
--

DROP TABLE IF EXISTS `pa_usermeta`;
CREATE TABLE `pa_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pa_usermeta`
--

INSERT INTO `pa_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(27, 2, 'nickname', 'admin'),
(28, 2, 'first_name', ''),
(29, 2, 'last_name', ''),
(30, 2, 'description', ''),
(31, 2, 'rich_editing', 'true'),
(32, 2, 'syntax_highlighting', 'true'),
(33, 2, 'comment_shortcuts', 'false'),
(34, 2, 'admin_color', 'fresh'),
(35, 2, 'use_ssl', '0'),
(36, 2, 'show_admin_bar_front', 'false'),
(37, 2, 'locale', ''),
(38, 2, 'pa_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(39, 2, 'pa_user_level', '10'),
(40, 2, 'dismissed_wp_pointers', ''),
(41, 2, 'session_tokens', 'a:3:{s:64:\"b170901439c2246354725b99d431e8b44cd5a380c655a741f6e6a141f64ef3d5\";a:4:{s:10:\"expiration\";i:1668565220;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36\";s:5:\"login\";i:1667355620;}s:64:\"e61d22afe502844e788b0baf1ddb5d0c30fd92a501998883d758a36e5e6df925\";a:4:{s:10:\"expiration\";i:1668734434;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36\";s:5:\"login\";i:1667524834;}s:64:\"56b3370a16eacd6ba96a38e4166d769ba6ddbba7e3f9ecf5e2a386f02560d039\";a:4:{s:10:\"expiration\";i:1668258823;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36\";s:5:\"login\";i:1668086023;}}'),
(42, 2, 'gform_recent_forms', 'a:1:{i:0;s:1:\"1\";}'),
(43, 2, 'pa_dashboard_quick_press_last_post_id', '205'),
(44, 2, 'pa_user-settings', 'libraryContent=browse'),
(45, 2, 'pa_user-settings-time', '1667326363'),
(46, 2, 'pa_persisted_preferences', 'a:2:{s:14:\"core/edit-post\";a:2:{s:26:\"isComplementaryAreaVisible\";b:1;s:12:\"welcomeGuide\";b:0;}s:9:\"_modified\";s:24:\"2022-11-04T01:21:07.741Z\";}');
