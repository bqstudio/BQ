
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pa_term_relationships`
--

DROP TABLE IF EXISTS `pa_term_relationships`;
CREATE TABLE `pa_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pa_term_relationships`
--

INSERT INTO `pa_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(6, 1, 0),
(23, 1, 0),
(27, 1, 0),
(36, 1, 0),
(100, 1, 0),
(120, 1, 0),
(127, 1, 0),
(128, 1, 0),
(153, 1, 0),
(154, 1, 0),
(155, 1, 0),
(156, 1, 0),
(193, 2, 0);
